import { NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase/admin'

export async function POST(req: Request) {
  try {
    const body = await req.json()

    const {
      email,
      applicant_name,
      national_id,
      address,
      phone,
      province,
      district,
      gun_uid,
      officer_email,
      attachments,
    } = body

    if (!email || !gun_uid || !officer_email) {
      return NextResponse.json({ error: 'Missing fields' }, { status: 400 })
    }

    const { data, error } = await supabaseAdmin
      .from('applications')
      .insert({
        applicant_email: email,
        applicant_name,
        national_id,
        address,
        phone,
        province,
        district,
        gun_uid,
        officer_email,
        attachments,
      })
      .select()
      .single()

    if (error) {
      console.error(error)
      return NextResponse.json({ error: 'Insert failed' }, { status: 500 })
    }

    return NextResponse.json({ ok: true, application_uid: data.application_uid })
  } catch (err) {
    console.error(err)
    return NextResponse.json({ error: 'Server error' }, { status: 500 })
  }
}
