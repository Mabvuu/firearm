'use client'

import { useState, useEffect, useMemo } from 'react'
import { ethers, type Eip1193Provider } from 'ethers'
import NavPage from '../nav/page'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { FirearmTokenABI } from '@/lib/FirearmTokenABI'
import { supabase } from '@/lib/supabase/client'

const CONTRACT_ADDRESS = '0x7EF2e0048f5bAeDe046f6BF797943daF4ED8CB47'

type InventoryGun = {
  id: number
  serial: string
  make: string
  model: string
  caliber: string
  date_of_import: string
  minted: boolean
}

export default function MintPage() {
  const [inventory, setInventory] = useState<InventoryGun[]>([])
  const [query, setQuery] = useState('')
  const [selectedGun, setSelectedGun] = useState<InventoryGun | null>(null)
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    async function fetchInventory() {
      const {
        data: { user }
      } = await supabase.auth.getUser()

      if (!user) return

      const { data } = await supabase
        .from('inventory')
        .select('*')
        .eq('minted', false)
        .eq('owner_id', user.id)

      setInventory(data || [])
    }

    fetchInventory()
  }, [])

  const filteredInventory = useMemo(() => {
    const q = query.toLowerCase()
    return inventory.filter(g =>
      g.serial.toLowerCase().includes(q) ||
      g.make.toLowerCase().includes(q) ||
      g.model.toLowerCase().includes(q)
    )
  }, [inventory, query])

  async function mintGun() {
    if (!selectedGun) {
      alert('Select a firearm first')
      return
    }

    const ethereum = (globalThis as unknown as {
      ethereum?: Eip1193Provider
    }).ethereum

    if (!ethereum) {
      alert('MetaMask required')
      return
    }

    setLoading(true)

    try {
      const provider = new ethers.BrowserProvider(ethereum)
      const signer = await provider.getSigner()

      const contract = new ethers.Contract(
        CONTRACT_ADDRESS,
        FirearmTokenABI,
        signer
      )

      const tx = await contract.mintFirearm(
        selectedGun.serial, // ✅ serial copied
        selectedGun.make,
        selectedGun.model,
        selectedGun.caliber,
        Math.floor(
          new Date(selectedGun.date_of_import).getTime() / 1000
        ), // ✅ date copied
        'OWNER-ID-123'
      )

      await tx.wait()

      await supabase
        .from('inventory')
        .update({ minted: true })
        .eq('id', selectedGun.id)

      setInventory(prev => prev.filter(g => g.id !== selectedGun.id))
      setSelectedGun(null)
      setQuery('')

      alert('Firearm minted successfully')
    } catch (err) {
      console.error(err)
      alert('Mint failed')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="flex min-h-screen">
      <div className="w-1/4 border-r">
        <NavPage />
      </div>

      <div className="w-3/4 p-6">
        <h1 className="text-2xl font-bold mb-6">Mint Firearm</h1>

        <div className="max-w-xl space-y-4">
          <Input
            placeholder="Search inventory (serial, make, model)"
            value={query}
            onChange={e => setQuery(e.target.value)}
          />

          {filteredInventory.length > 0 && (
            <div className="border rounded max-h-48 overflow-y-auto">
              {filteredInventory.map(g => (
                <div
                  key={g.id}
                  className="px-3 py-2 cursor-pointer hover:bg-gray-100"
                  onClick={() => setSelectedGun(g)}
                >
                  {g.serial} | {g.make} {g.model} | {g.caliber}
                </div>
              ))}
            </div>
          )}

          {selectedGun && (
            <div className="border rounded p-3 bg-gray-50 space-y-1">
              <p><b>Serial:</b> {selectedGun.serial}</p>
              <p><b>Make:</b> {selectedGun.make}</p>
              <p><b>Model:</b> {selectedGun.model}</p>
              <p><b>Caliber:</b> {selectedGun.caliber}</p>
              <p><b>Date:</b> {selectedGun.date_of_import}</p>
            </div>
          )}

          <Button onClick={mintGun} disabled={loading || !selectedGun}>
            {loading ? 'Minting…' : 'Mint Firearm'}
          </Button>
        </div>
      </div>
    </div>
  )
}
