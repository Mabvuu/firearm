'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { supabase } from '@/lib/supabase/client'
import type { Eip1193Provider } from 'ethers'

export default function NavPage() {
  const router = useRouter()
  const [wallet, setWallet] = useState<string | null>(null)
  const [mounted, setMounted] = useState(false)

  // Hydration-safe: only update state after mount
  useEffect(() => {
    const init = () => {
      const stored = localStorage.getItem('registeredWallet')
      if (stored) setWallet(stored)
      setMounted(true)
    }

    // Schedule on next tick
    setTimeout(init, 0)
  }, [])

  const connectWallet = async () => {
    const ethereum = (globalThis as { ethereum?: Eip1193Provider }).ethereum
    if (!ethereum) return alert('MetaMask required')

    try {
      const accounts = await ethereum.request({ method: 'eth_requestAccounts' })
      const address = accounts[0]
      localStorage.setItem('registeredWallet', address)
      setWallet(address)
    } catch (err) {
      console.error(err)
      alert('Failed to connect wallet')
    }
  }

  const removeWallet = () => {
    localStorage.removeItem('registeredWallet')
    setWallet(null)
  }

  const handleLogout = async () => {
    await supabase.auth.signOut()
    localStorage.removeItem('registeredWallet')
    router.replace('/login')
  }

  if (!mounted) return <aside className="h-full p-4">LOGO</aside>

  return (
    <aside className="h-full p-4 flex flex-col">
      {/* Wallet */}
      <div className="mb-6">
        {!wallet ? (
          <div className="space-y-2">
            <div className="text-xl font-bold">LOGO</div>
            <Button onClick={connectWallet} className="w-full">Add Wallet</Button>
            <p className="text-xs text-red-500">Please add your wallet</p>
          </div>
        ) : (
          <div className="space-y-2">
            <div className="text-xs font-mono break-all">{wallet}</div>
            <Button variant="outline" size="sm" onClick={removeWallet} className="w-full">Remove Wallet</Button>
          </div>
        )}
      </div>

      {/* Navigation */}
      <nav className="flex flex-col gap-2">
        <Link href="/dealer/dashboard"><Button variant="ghost" className="w-full justify-start">Home</Button></Link>
        <Link href="/dealer/mint"><Button variant="ghost" className="w-full justify-start">Mint</Button></Link>
        <Link href="/dealer/application"><Button variant="ghost" className="w-full justify-start">Application</Button></Link>
        <Link href="/dealer/inventory"><Button variant="ghost" className="w-full justify-start">Inventory</Button></Link>
        <Link href="/dealer/audit"><Button variant="ghost" className="w-full justify-start">Audit</Button></Link>
        <Link href="/dealer/profile"><Button variant="ghost" className="w-full justify-start">Profile</Button></Link>
      </nav>

      {/* Logout */}
      <div className="mt-auto pt-6">
        <Button variant="destructive" className="w-full" onClick={handleLogout}>Logout</Button>
      </div>
    </aside>
  )
}
