'use client'

import { useMemo, useState } from 'react'
import NavPage from '../nav/page'
import { supabase } from '@/lib/supabase/client'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'

type Gun = {
  id: number
  make: string
  model: string
  caliber: string | null
  serial: string | null
}

export default function DealerApplicationPage() {
  const [form, setForm] = useState({
    applicant_name: '',
    national_id: '',
    address: '',
    phone: '',
    province: '',
    district: '',
    gun_uid: null as number | null, // inventory.id
    officer_email: '',
  })

  const [files, setFiles] = useState<File[]>([])

  // firearms
  const [guns, setGuns] = useState<Gun[]>([])
  const [showGunPicker, setShowGunPicker] = useState(false)
  const [gunQuery, setGunQuery] = useState('')

  // officers
  const [officers, setOfficers] = useState<{ email: string }[]>([])
  const [showOfficerPicker, setShowOfficerPicker] = useState(false)
  const [officerQuery, setOfficerQuery] = useState('')

  const loadMintedGuns = async () => {
    const { data, error } = await supabase
      .from('inventory')
      .select('id, make, model, caliber, serial')
      .eq('minted', true)

    if (error) {
      console.error(error)
      alert('Failed to load firearms')
      return
    }

    setGuns(data || [])
  }

  const loadOfficers = async () => {
    const res = await fetch('/api/firearm-officers')
    const data = await res.json()
    setOfficers(data || [])
  }

  const filteredGuns = useMemo(() => {
    return guns.filter(g =>
      `${g.make} ${g.model} ${g.serial ?? ''}`
        .toLowerCase()
        .includes(gunQuery.toLowerCase())
    )
  }, [guns, gunQuery])

  const filteredOfficers = useMemo(() => {
    return officers.filter(o =>
      o.email.toLowerCase().includes(officerQuery.toLowerCase())
    )
  }, [officers, officerQuery])

  const submitApplication = async () => {
    try {
      const {
        data: { user },
        error,
      } = await supabase.auth.getUser()

      if (error || !user?.email) {
        alert('Not logged in')
        return
      }

      if (!form.gun_uid) {
        alert('Select a firearm')
        return
      }

      if (!form.officer_email) {
        alert('Select an officer')
        return
      }

      const uploaded: string[] = []

      for (const file of files) {
        const path = `applications/${user.email}/${crypto.randomUUID()}-${file.name}`
        const { error } = await supabase.storage
          .from('applications')
          .upload(path, file)

        if (error) {
          console.error(error)
          alert('File upload failed')
          return
        }

        uploaded.push(path)
      }

      const res = await fetch('/api/dealer/application', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: user.email,
          ...form,
          attachments: uploaded,
        }),
      })

      const data = await res.json()

      if (!res.ok) {
        console.error(data)
        alert('Application failed')
        return
      }

      alert(`Application submitted\nUID: ${data.application_uid}`)
    } catch (err) {
      console.error(err)
      alert('Unexpected error')
    }
  }

  return (
    <div className="flex min-h-screen">
      <div className="w-1/4 border-r">
        <NavPage />
      </div>

      <div className="w-3/4 p-8">
        <Card>
          <CardHeader>
            <CardTitle>New Firearm Application</CardTitle>
          </CardHeader>

          <CardContent className="grid grid-cols-2 gap-4">
            <Input placeholder="Full name" value={form.applicant_name}
              onChange={e => setForm({ ...form, applicant_name: e.target.value })} />

            <Input placeholder="National ID" value={form.national_id}
              onChange={e => setForm({ ...form, national_id: e.target.value })} />

            <Input placeholder="Address" value={form.address}
              onChange={e => setForm({ ...form, address: e.target.value })} />

            <Input placeholder="Phone" value={form.phone}
              onChange={e => setForm({ ...form, phone: e.target.value })} />

            <Input placeholder="Province" value={form.province}
              onChange={e => setForm({ ...form, province: e.target.value })} />

            <Input placeholder="District" value={form.district}
              onChange={e => setForm({ ...form, district: e.target.value })} />

            {/* FILES */}
            <div className="col-span-2">
              <Input type="file" multiple accept="application/pdf,image/*"
                onChange={e => setFiles(Array.from(e.target.files || []))} />
            </div>

            {/* FIREARM */}
            <div className="col-span-2 space-y-2">
              <Button type="button" onClick={() => {
                setShowGunPicker(true)
                if (!guns.length) loadMintedGuns()
              }}>
                Attach Firearm
              </Button>

              {form.gun_uid && (
                <div className="border p-2 text-sm">
                  Attached firearm ID: {form.gun_uid}
                </div>
              )}

              {showGunPicker && (
                <div className="border p-2">
                  <Input placeholder="Search firearm"
                    value={gunQuery}
                    onChange={e => setGunQuery(e.target.value)} />

                  <div className="max-h-40 overflow-y-auto">
                    {filteredGuns.map(g => (
                      <div key={g.id}
                        className="p-2 cursor-pointer hover:bg-muted"
                        onClick={() => {
                          setForm({ ...form, gun_uid: g.id })
                          setShowGunPicker(false)
                        }}>
                        {g.make} {g.model} | {g.serial} | ID {g.id}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* OFFICER */}
            <div className="col-span-2 space-y-2">
              <Button type="button" onClick={() => {
                setShowOfficerPicker(true)
                if (!officers.length) loadOfficers()
              }}>
                Send To Firearm Officer
              </Button>

              {form.officer_email && (
                <div className="border p-2 text-sm">
                  Selected: {form.officer_email}
                </div>
              )}

              {showOfficerPicker && (
                <div className="border p-2">
                  <Input placeholder="Search officer email"
                    value={officerQuery}
                    onChange={e => setOfficerQuery(e.target.value)} />

                  <div className="max-h-40 overflow-y-auto">
                    {filteredOfficers.map(o => (
                      <div key={o.email}
                        className="p-2 cursor-pointer hover:bg-muted"
                        onClick={() => {
                          setForm({ ...form, officer_email: o.email })
                          setShowOfficerPicker(false)
                        }}>
                        {o.email}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <div className="col-span-2">
              <Button type="button" onClick={submitApplication}>
                Submit Application
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
  