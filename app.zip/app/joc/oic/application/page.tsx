'use client'

export default function JocOICPage() {
  const approve = async () => {
    // POST /api/joc/oic/approve
  }

  const deny = async () => {
    // POST /api/joc/oic/deny
  }

  return (
    <div>
      <h1>JOC OIC Review</h1>

      <button onClick={approve}>Approve</button>
      <button onClick={deny}>Deny</button>
    </div>
  )
}
