'use client'

export default function ControllerPage() {
  const finalize = async () => {
    // POST /api/joc/controller/final-approve
    // create wallet + move token
  }

  return (
    <div>
      <h1>Controller Final Approval</h1>

      <button onClick={finalize}>Approve & Issue License</button>
    </div>
  )
}
