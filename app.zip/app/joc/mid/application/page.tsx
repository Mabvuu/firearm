'use client'

export default function MIDPage() {
  const approve = async () => {
    // POST /api/joc/mid/approve
  }

  const deny = async () => {
    // POST /api/joc/mid/deny
  }

  return (
    <div>
      <h1>MID Review</h1>

      <button onClick={approve}>Approve</button>
      <button onClick={deny}>Deny</button>
    </div>
  )
}
