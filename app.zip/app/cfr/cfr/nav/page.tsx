import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function NavPage() {
  return (
    <aside className="h-full p-4 flex flex-col">
      <div className="mb-6 text-xl font-bold">LOGO</div>

      <nav className="flex flex-col gap-2">
        <Link href="/cfr/dashboard"><Button variant="ghost" className="w-full justify-start">Home</Button></Link>
        <Link href="/cfr/application"><Button variant="ghost" className="w-full justify-start">Application</Button></Link>
        <Link href="/cfr/applicants"><Button variant="ghost" className="w-full justify-start">Applicants</Button></Link>
       
        <Link href="/cfr/audit"><Button variant="ghost" className="w-full justify-start">Audit</Button></Link>
       
        <Link href="/cfr/profile"><Button variant="ghost" className="w-full justify-start">profile</Button></Link>
      </nav>

      <div className="mt-auto pt-6">
        <Button variant="destructive" className="w-full">Logout</Button>
      </div>
    </aside>
  )
}
