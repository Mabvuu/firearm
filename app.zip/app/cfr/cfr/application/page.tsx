'use client'

export default function CFRPage() {
  const forward = async () => {
    // POST /api/cfr/forward
  }

  return (
    <div>
      <h1>CFR Vetting</h1>

      <textarea placeholder="CFR Notes" />
      <button onClick={forward}>Send to Dispol</button>
    </div>
  )
}
