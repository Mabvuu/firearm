export default function PropolDashboard() {
return (
<div className="p-6">
<h1 className="text-2xl font-bold">CFR – Province Police Dashboard</h1>
</div>
)
}