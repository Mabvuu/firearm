'use client'

export default function PropolPage() {
  const approve = async () => {
    // POST /api/propol/approve
  }

  const deny = async () => {
    // POST /api/propol/deny
  }

  return (
    <div>
      <h1>Propol Review</h1>

      <button onClick={approve}>Approve</button>
      <button onClick={deny}>Deny</button>
    </div>
  )
}
