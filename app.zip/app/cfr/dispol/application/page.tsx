'use client'

export default function DispolPage() {
  const approve = async () => {
    // POST /api/dispol/approve
  }

  const deny = async () => {
    // POST /api/dispol/deny
  }

  return (
    <div>
      <h1>Dispol Review</h1>

      <button onClick={approve}>Approve</button>
      <button onClick={deny}>Deny</button>
    </div>
  )
}
