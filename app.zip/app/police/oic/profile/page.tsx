'use client'

import { useEffect, useState, ChangeEvent } from 'react'
import NavPage from '../nav/page'
import { supabase } from '@/lib/supabase/client'
import { PROVINCES } from '@/lib/provinces'
import { AccountDetails } from '@/lib/types/account-details'
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'

export default function PoliceOicProfilePage() {
  const [form, setForm] = useState<AccountDetails>({
    role: 'police-oic',
    national_id: '',
    name: '',
    surname: '',
    province: '',
    city: '',
    police_address: '',
    contact_number: '',
    badge_number: ''
  })

  useEffect(() => {
    const load = async () => {
      const { data } = await supabase.auth.getSession()
      const token = data.session?.access_token
      if (!token) return

      const res = await fetch('/api/account-details', {
        headers: { Authorization: `Bearer ${token}` }
      })

      const profile = (await res.json()) as AccountDetails | null
      if (profile) setForm(profile)
    }
    load()
  }, [])

  const onChange = (
    e: ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target
    setForm(p => ({ ...p, [name]: value }))
  }

  const save = async () => {
    const { data } = await supabase.auth.getSession()
    const token = data.session?.access_token
    if (!token) return

    await fetch('/api/account-details', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`
      },
      body: JSON.stringify(form)
    })
  }

  return (
    <div className="flex min-h-screen">
      <NavPage />
      <div className="p-6 max-w-lg w-full">
        <Card>
          <CardHeader>
            <CardTitle>Police OIC Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <Input name="national_id" placeholder="National ID" value={form.national_id} onChange={onChange} />
            <Input name="name" placeholder="Name" value={form.name} onChange={onChange} />
            <Input name="surname" placeholder="Surname" value={form.surname} onChange={onChange} />

            <select name="province" className="w-full border rounded p-2" value={form.province} onChange={onChange}>
              <option value="">Select province</option>
              {PROVINCES.map(p => <option key={p} value={p}>{p}</option>)}
            </select>

            <Input name="city" placeholder="City / Town" value={form.city} onChange={onChange} />
            <Input name="police_address" placeholder="Police Address" value={form.police_address ?? ''} onChange={onChange} />
            <Input name="badge_number" placeholder="Badge Number" value={form.badge_number ?? ''} onChange={onChange} />
            <Input name="contact_number" placeholder="Contact Number" value={form.contact_number} onChange={onChange} />

            <Button onClick={save}>Save</Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
