'use client'

import { useEffect, useState, useCallback } from 'react'
import NavPage from '../nav/page'
import { supabase } from '@/lib/supabase/client'
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion'
import { Badge } from '@/components/ui/badge'

type Application = {
  id: number
  applicant_name: string
  applicant_email: string
  national_id: string
  address: string
  phone: string
  province: string
  district: string
  gun_uid: number
  status: string
  attachments: string[] | null
}

type Gun = {
  id: number
  make: string
  model: string
  caliber: string | null
  serial: string | null
}

const statusColor = (status: string) => {
  switch (status) {
    case 'unread':
      return 'bg-blue-500'
    case 'forwarded':
      return 'bg-green-500'
    case 'returned':
      return 'bg-red-500'
    default:
      return 'bg-gray-400'
  }
}

export default function FirearmOfficerApplicationsPage() {
  const [apps, setApps] = useState<Application[]>([])
  const [guns, setGuns] = useState<Record<number, Gun>>({})
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const loadApps = async () => {
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user?.email) return

      const { data } = await supabase
        .from('applications')
        .select('*')
        .eq('officer_email', user.email)
        .order('created_at', { ascending: false })

      setApps(data || [])
      setLoading(false)
    }

    loadApps()
  }, [])

  const loadGun = useCallback(async (gunId: number) => {
    if (guns[gunId]) return

    const { data } = await supabase
      .from('inventory')
      .select('id, make, model, caliber, serial')
      .eq('id', gunId)
      .single()

    if (data) {
      setGuns(prev => ({ ...prev, [gunId]: data }))
    }
  }, [guns])

  useEffect(() => {
    apps.forEach(app => {
      if (app.gun_uid) loadGun(app.gun_uid)
    })
  }, [apps, loadGun])

  const updateStatus = async (id: number, status: string) => {
    await supabase
      .from('applications')
      .update({ status })
      .eq('id', id)

    setApps(prev =>
      prev.map(a => (a.id === id ? { ...a, status } : a))
    )
  }

  if (loading) return <div className="p-8">Loading…</div>

  return (
    <div className="flex min-h-screen">
      <div className="w-1/4 border-r">
        <NavPage />
      </div>

      <div className="w-3/4 p-8">
        <Card>
          <CardHeader>
            <CardTitle>Assigned Applications</CardTitle>
          </CardHeader>

          <CardContent>
            <Accordion type="single" collapsible className="space-y-2">
              {apps.map(app => (
                <AccordionItem key={app.id} value={String(app.id)}>
                  <AccordionTrigger className="flex items-center gap-3 px-4">
                    <div
                      className={`w-2 h-8 rounded ${statusColor(app.status)}`}
                    />
                    <div className="flex-1 text-left">
                      <div className="font-medium">
                        {app.applicant_name}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        Dealer: {app.applicant_email}
                      </div>
                    </div>
                    <Badge variant="outline">{app.status}</Badge>
                  </AccordionTrigger>

                  <AccordionContent className="p-4 space-y-4">
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div><b>National ID:</b> {app.national_id}</div>
                      <div><b>Phone:</b> {app.phone}</div>
                      <div><b>Address:</b> {app.address}</div>
                      <div><b>Province:</b> {app.province}</div>
                      <div><b>District:</b> {app.district}</div>
                    </div>

                    <div className="border rounded p-3">
                      <div className="font-semibold mb-1">
                        Firearm Details
                      </div>
                      {guns[app.gun_uid] ? (
                        <div className="text-sm space-y-1">
                          <div>Make: {guns[app.gun_uid].make}</div>
                          <div>Model: {guns[app.gun_uid].model}</div>
                          <div>Caliber: {guns[app.gun_uid].caliber}</div>
                          <div>Serial: {guns[app.gun_uid].serial}</div>
                        </div>
                      ) : (
                        <div className="text-sm text-muted-foreground">
                          Loading firearm…
                        </div>
                      )}
                    </div>

                    {app.attachments?.length ? (
                      <div>
                        <div className="font-semibold">Attachments</div>
                        {app.attachments.map(path => {
                          const url = supabase.storage
                            .from('applications')
                            .getPublicUrl(path).data.publicUrl

                          return (
                            <a
                              key={path}
                              href={url}
                              target="_blank"
                              className="text-blue-600 underline block text-sm"
                            >
                              View file
                            </a>
                          )
                        })}
                      </div>
                    ) : null}

                    <div className="flex gap-2 pt-2">
                      <Button
                        size="sm"
                        onClick={() => updateStatus(app.id, 'forwarded')}
                      >
                        Move Forward
                      </Button>
                      <Button
                        size="sm"
                        variant="destructive"
                        onClick={() => updateStatus(app.id, 'returned')}
                      >
                        Return
                      </Button>
                    </div>
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
