// app/police/firearmofficer/nav/page.tsx
import Link from 'next/link'
import { Button } from '@/components/ui/button'

export default function NavPage() {
  return (
    <aside className="h-full p-4 flex flex-col">
      <div className="mb-6 text-xl font-bold">LOGO</div>

      <nav className="flex flex-col gap-2">
        <Link href="/police/firearmofficer/dashboard">
          <Button variant="ghost" className="w-full justify-start">
            Home
          </Button>
        </Link>

        <Link href="/police/firearmofficer/application">
          <Button variant="ghost" className="w-full justify-start">
            Applications
          </Button>
        </Link>

        <Link href="/police/firearmofficer/competency">
          <Button variant="ghost" className="w-full justify-start">
            Competency
          </Button>
        </Link>

        <Link href="/police/firearmofficer/applicants">
          <Button variant="ghost" className="w-full justify-start">
            Applicants
          </Button>
        </Link>

        <Link href="/police/firearmofficer/audit">
          <Button variant="ghost" className="w-full justify-start">
            Audit
          </Button>
        </Link>

        <Link href="/police/firearmofficer/profile">
          <Button variant="ghost" className="w-full justify-start">
            Profile
          </Button>
        </Link>
      </nav>

      <div className="mt-auto pt-6">
        <Button variant="destructive" className="w-full">
          Logout
        </Button>
      </div>
    </aside>
  )
}
